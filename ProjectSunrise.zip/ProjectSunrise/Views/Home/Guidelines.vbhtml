﻿@Code
    ViewBag.Title = "Guidelines"
End Code
<div class="container py-5">
    <div class="mx-auto" style="max-width: 850px;">
        <h1 class="mb-3">Community Guidelines</h1>
        <p class="lead text-muted">
            These simple expectations help keep NTChat respectful, useful, and enjoyable for everyone.
        </p>

        <div class="row g-4 mt-2">
            <div class="col-md-6">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h2 class="h5">Be respectful</h2>
                        <p class="mb-0 text-muted">
                            Engage with others in good faith. Personal attacks, harassment, and toxic behavior have no place here.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h2 class="h5">Stay on topic</h2>
                        <p class="mb-0 text-muted">
                            Use room categories and tags properly so conversations remain organized and useful for members.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h2 class="h5">Share responsibly</h2>
                        <p class="mb-0 text-muted">
                            Avoid spam, misleading content, or anything that would disrupt the room experience for others.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h2 class="h5">Respect moderation</h2>
                        <p class="mb-0 text-muted">
                            Staff and room managers may step in when content breaks community expectations or platform rules.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
